
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Http.Headers;
using UnityEngine;

public class MapCreator : MonoBehaviour
{
    //��ʼ��װ�ε�ͼ�������������
    //0-flag 1-wall 2-barrier 3-born 4-river 5-bush 6-airBarrier 
    public GameObject[] item;
    //�Ѿ��ж�����λ���б� 
    private List<Vector3> PosList=new List<Vector3>();
    private void Awake()
    {
        IniMap();
    }
    private void IniMap()
    {
        CreateItem(item[0], new Vector3(0, -6, 0), Quaternion.identity);
        Debug.Log("flag");
        CreateItem(item[1], new Vector3(1, -6, 0), Quaternion.identity);
        Debug.Log("wall");
        CreateItem(item[1], new Vector3(-1, -6, 0), Quaternion.identity);
        Debug.Log("wall");
        for (int i = -1; i < 2; i++)
        {
            CreateItem(item[1], new Vector3(i, -5, 0), Quaternion.identity);
        }
        //ʵ������Χǽ
        for(int i = -14; i <= 14; i++)
        {
            CreateItem(item[2], new Vector3(i, 7, 0), Quaternion.identity);
            CreateItem(item[2], new Vector3(i, -7, 0), Quaternion.identity);
        }
        for (int i = -7; i <= 7; i++)
        {
            CreateItem(item[2], new Vector3(14, i, 0), Quaternion.identity);
            CreateItem(item[2], new Vector3(-14, i, 0), Quaternion.identity);
        }
        //ʵ������ͼ���������
        for(int i = 0; i < 60; i++)
        {
            CreateItem(item[1], CreatRandomPos(), Quaternion.identity);
        }
        for (int i = 0; i < 20; i++)
        {
            CreateItem(item[2], CreatRandomPos(), Quaternion.identity);
        }
        for (int i = 0; i < 20; i++)
        {
            CreateItem(item[5], CreatRandomPos(), Quaternion.identity);
        }
        for (int i = 0; i < 20; i++)
        {
            CreateItem(item[4], CreatRandomPos(), Quaternion.identity);
        }
        //ʵ�������
        GameObject go = Instantiate(item[3], new Vector3(-2, -6, 0), Quaternion.identity);
        go.GetComponent<Born>().isPlayer = true;
        //�������ˣ�����
        CreateItem(item[3], new Vector3(-13, 6, 0), Quaternion.identity);
        CreateItem(item[3], new Vector3(2, 6, 0), Quaternion.identity);
        CreateItem(item[3], new Vector3(13, 6, 0), Quaternion.identity);

        InvokeRepeating("CreateEnemy", 4, 5);//��һ�������Ƿ��������ڶ��������ǵ�һ�ε��õ��ӳ�ʱ�䡣�ڶ���������ÿ������ٵ���һ��
    }
    private void CreateItem(GameObject createdGameObject,Vector3 createdPosition,Quaternion creatorRotation)
    {
        GameObject itemGo=Instantiate(createdGameObject, createdPosition, creatorRotation);
        itemGo.transform.SetParent(gameObject.transform);
        PosList.Add(createdPosition);
    }
 
    //�������λ�õķ���
    private Vector3 CreatRandomPos()
    {
        //������x=13��-13��y=6��-6��λ��
        while (true)
        {
            //ע�⣬����int����,Random.Range�ķ�Χ������Сֵ�����������ֵ
            Vector3 created_position = new Vector3(Random.Range(-12, 13), Random.Range(-5, 6), 0);
            if (!HasPos(created_position))
            {
                return created_position;
            }
        }
    }
    //�����ж�λ���б����Ƿ������λ��
    private bool HasPos(Vector3 pos)
    {
        for(int i = 0; i < PosList.Count; i++)
        {
            if (pos == PosList[i])
            {
                return true;
            }
        }
        return false;
    }
    //�������˵ķ���
    public void CreateEnemy()
    {
        int num_Enemy = Random.Range(1, 4);
        switch (num_Enemy)
        {
            case 1:
                CreateItem(item[3], new Vector3(-13, 6, 0), Quaternion.identity);
                break;
            case 2:
                CreateItem(item[3], new Vector3(-13, 6, 0), Quaternion.identity);
                CreateItem(item[3], new Vector3(13, 6, 0), Quaternion.identity);
                break;
            case 3:
                CreateItem(item[3], new Vector3(-13, 6, 0), Quaternion.identity);
                CreateItem(item[3], new Vector3(2, 6, 0), Quaternion.identity);
                CreateItem(item[3], new Vector3(13, 6, 0), Quaternion.identity);
                break;
        }
    }
}
