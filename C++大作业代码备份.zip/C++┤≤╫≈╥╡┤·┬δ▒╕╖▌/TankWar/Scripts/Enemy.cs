using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    private float MoveSpeed = 5.0f;
    public Sprite[] enemySprite;
    private Vector3 bulletEulerAngles;
    private float attackTimeVal;//��ʱ�������ӹ���cd
    private float turnTimeVal=4;//��ʱ��������ת��cd

    public float h;
    public float v;

    private SpriteRenderer sr;
    public GameObject explosionPrefab;
    public GameObject EnemyBulletPrefab;

    // Start is called before the first frame update
    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (attackTimeVal >= 3.0f)
        {
        EnemyAttack();
        }
        else
        {
        attackTimeVal += Time.deltaTime;
        }
    }
    private void FixedUpdate()
    {
       
            EnemyMove();
        
    }
    public void EnemyAttack()
    {
        //�ӵ������ĽǶ�Ӧ���ǵ�ǰ̹�˵ĽǶȼ��ӵ�Ӧ����ת�ĽǶ�
        Instantiate(EnemyBulletPrefab, transform.position, Quaternion.Euler(transform.eulerAngles + bulletEulerAngles));//ʵ�����ӵ�����Ҫʵ���������壬̹�˵�λ�ã���ת�Ƕ�
        attackTimeVal = 0;
    }
    public void EnemyDie()
    {
        PlayerManager.Instance.playerScore++;
        Instantiate(explosionPrefab, transform.position, transform.rotation);
        Destroy(gameObject);
    }
    public void EnemyMove()
    {
        if (turnTimeVal >= 4)
        {
            int note = Random.Range(0, 8);
            switch (note)
            {
                case 8:
                    v = -1;
                    h = 0;
                    break;
                case 7:
                    v = -1;
                    h = 0;
                    break;
                case 6:
                    v = -1;
                    h = 0;
                    break; 
                case 5:
                    v = -1;
                    h = 0;
                    break;
                case 4:
                    v = 0;
                    h = 1;
                    break;
                case 3:
                    v = 0;
                    h = 1;
                    break;
                case 2:
                    v = 0;
                    h = -1;
                    break;
                case 1:
                    v = 0;
                    h = -1;
                    break;
                case 0:
                    v = 1;
                    h = 0;
                    break;
                default:
                    break;
            }
            turnTimeVal = 0;
        }
        else
        {
            turnTimeVal += Time.fixedDeltaTime;
        }
        Vector3 direction = new Vector3(h, v, 0);
        Vector3 directionX = new Vector3((direction.x), 0, 0);
        Vector3 directionY = new Vector3(0, (direction.y), 0);
        transform.Translate(directionX * MoveSpeed * Time.fixedDeltaTime, Space.World);
        if (direction.x > 0)
        {
            sr.sprite = enemySprite[1];
            bulletEulerAngles = new Vector3(0, 0, -90);
        }
        else if (direction.x < 0)
        {
            sr.sprite = enemySprite[3];
            bulletEulerAngles = new Vector3(0, 0, 90);
        }
        if (direction.x != 0)
        {
            return;
        }
       
        transform.Translate(directionY * MoveSpeed * Time.fixedDeltaTime, Space.World);
        if (direction.y > 0)
        {
            sr.sprite = enemySprite[0];
            bulletEulerAngles = new Vector3(0, 0, 0);
        }
        else if (direction.y < 0)
        {
            sr.sprite = enemySprite[2];
            bulletEulerAngles = new Vector3(0, 0, 180);
        }
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Enemy")
        {
            turnTimeVal = 4;
        }
    }
}