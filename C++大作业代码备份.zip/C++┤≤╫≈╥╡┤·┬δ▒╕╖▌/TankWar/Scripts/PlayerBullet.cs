using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBullet : MonoBehaviour
{
    public float moveSpeed = 10;
	 public AudioClip fireAudio;
	public bool isPlayerBullet = false;//Ĭ����false
    // Start is called before the first frame update
	private void Awake()
    {
        AudioSource.PlayClipAtPoint(fireAudio,transform.position);
    }
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(transform.up * moveSpeed * Time.deltaTime, Space.World);
    }
	private void OnTriggerEnter2D(Collider2D collision)
	{
		switch(collision.tag)
		{
			case "Tank":
				if (!isPlayerBullet)
				{
					collision.SendMessage("Die");
                    Destroy(gameObject);
                }
                break;
            case "Flag":
				collision.SendMessage("Die");
                Destroy(gameObject);
                break;
			case "Enemy":
                collision.SendMessage("EnemyDie");
                Destroy(gameObject);
                break;
			case "Barrier":
				Destroy(gameObject);
				break;
			case "Wall":
				collision.SendMessage("Die");
				Destroy(gameObject);
				break;
			case "AirBarrier":
                Destroy(gameObject);
                break;
			default:
				break;
		}
		
	}
}
