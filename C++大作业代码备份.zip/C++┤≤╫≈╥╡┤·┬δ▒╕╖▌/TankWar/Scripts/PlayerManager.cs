using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerManager : MonoBehaviour
{
   
    public int lifeValue = 3;
    public int playerScore=0;
    public bool isDead = false;
    public bool isLose = false;
    public GameObject bornPrefab;
    public Text PlayerScoreText;
    public Text PlayerLifeValueText;
    public GameObject GameOverImage;
   //声明为private，实现单例化
    private static PlayerManager instance;
    //crl+R+E
    public static PlayerManager Instance 
    {   
        get => instance; 
        set => instance = value; 
    }

    private void Awake()
    {
        Instance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (isDead)
        {
            Recover();
        }
        PlayerScoreText.text=playerScore.ToString();
        PlayerLifeValueText.text=lifeValue.ToString();

        if(isLose){
            GameOverImage.SetActive(true);
            Invoke("ReturnToMenu",3);
        }
    }
    private void Recover()
    {
        if (lifeValue <= 0||isLose==true)
        {
            //游戏结束，返回主界面
            isDead = true;
            isLose=true;
           
        }
        else if (lifeValue > 0)
        {
            lifeValue--;
            GameObject go = Instantiate(bornPrefab, new Vector3(-2, -6, 0), Quaternion.identity);
            go.GetComponent<Born>().isPlayer = true;
            isDead=false;
        }
    }
    //返回主界面
    private void ReturnToMenu()
    {
        SceneManager.LoadScene(0);
    }
}
