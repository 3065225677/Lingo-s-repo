using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public float moveSpeed = 10;
     public AudioClip fireAudio;
    public bool isEnemyBullet = false;//Ĭ����false
    private void Awake()
    {
        AudioSource.PlayClipAtPoint(fireAudio,transform.position);
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(transform.up * moveSpeed * Time.deltaTime, Space.World);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "Tank":
                collision.SendMessage("Die");
                Destroy(gameObject);
                break;
            case "Flag":
                collision.SendMessage("Die");
                Destroy(gameObject);
                break;
            case "Enemy":
                if (!isEnemyBullet)
                {
                    collision.SendMessage("EnemyDie");
                    Destroy(gameObject);
                }
                break;
            case "Barrier":
                Destroy(gameObject);
                break;
            case "Wall":
                collision.SendMessage("Die");
                Destroy(gameObject);
                break;
            case "AirBarrier":
                Destroy(gameObject);
                break;
            default:
                break;
        }

    }
}