using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class Option : MonoBehaviour
{
    private int choice=1;
    public Transform posOne;
    public Transform posTwo;
    public Sprite[] option;
    //private SpriteRenderer _sr;
    //private Image[] images;
    //private Image image;

    // Start is called before the first frame update
    void Start()
    {
        //_sr= GetComponent<SpriteRenderer>();
        //image=GetComponent<Image>();
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if(Input.GetKeyDown(KeyCode.W))
        {
            choice=1;
            transform.position=posOne.position;
            //_sr.sprite = option[choice-1];
            //image.image =images[choice] as Texture ;
        }
        else if(Input.GetKeyDown(KeyCode.S))
        {
            choice=2;
            transform.position=posTwo.position;
            //_sr.sprite = option[choice - 1];
        }
        if(choice==1&&Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene(1);
        }
        if (choice == 2 && Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene(2);
        }
    }
}
