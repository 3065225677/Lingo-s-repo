using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flag : MonoBehaviour
{
    private SpriteRenderer sr;
    public Sprite flag_broken;
    public GameObject explosionPrefab;
    public AudioClip loseAudio;

    // Start is called before the first frame update
    void Start()
    {
        //һ��Ҫ�����в��ܲٿ�sr��sprite��Ⱦ�������
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
       
    }
    public void Die()
    {
        PlayerManager.Instance.isLose=true;
        Instantiate(explosionPrefab,transform.position,transform.rotation);
        sr.sprite = flag_broken;
        AudioSource.PlayClipAtPoint(loseAudio,transform.position);
    }
}
