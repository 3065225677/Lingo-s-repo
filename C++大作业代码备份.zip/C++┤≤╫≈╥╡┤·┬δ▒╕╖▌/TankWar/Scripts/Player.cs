using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{   //属性
    public float moveSpeed = 5;
    private Vector3 bulletEulerAngles;
    private float attackTimeVal;//攻击间隔
    private float defendTimeVal=3;//保护 CD
    private bool isDefended=true;
    private bool hasTeleportation=false;

    //����
    private SpriteRenderer sr;
    public Sprite[] tankSprite;//��������,ע�ⲻ���ϴ�ͼƬ��0��8��16��24  ��������//�õ���Ⱦ��������
    public GameObject PlayerBulletPrefab;
    public GameObject explosionPrefab;
    public GameObject defendEffectPrefab;
    public GameObject teleportMarkerPrefab; // 传送标记预制体
    public float teleportCooldown = 1f; // 传送技能冷却时间

    private GameObject teleportMarker; // 当前的传送标记
    private bool canTeleport = true; // 是否可以使用传送技能
    private GameObject teleportMarker_test;
    

    // //�õ���Ⱦ��������
    private void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }
    // Start is called before the first frame update
    void Start()
    {

    }
    // Update is called once per frame
    void Update()
    {   if(PlayerManager.Instance.isLose)
        {
            return;
        }
        //�����޵е�CD
        if (isDefended)
        {
            defendEffectPrefab.SetActive(true);
            defendTimeVal -= Time.deltaTime;
            if (defendTimeVal <= 0)
            {
                isDefended = false;
                defendEffectPrefab.SetActive(false);
            }
        }

        //������CD
        if (attackTimeVal >= 0.4f){
            tankAttack();
			
		}
        else
            {attackTimeVal += Time.deltaTime;}
        SmallSkill_test();
    }
    private void FixedUpdate()
    {
        if(PlayerManager.Instance.isLose)
        {
            return;
        }
        tankMove();
        
    }
    //̹�˹����ķ���
    private void tankAttack()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //�ӵ������ĽǶ�Ӧ���ǵ�ǰ̹�˵ĽǶȼ��ӵ�Ӧ����ת�ĽǶ�
            Instantiate(PlayerBulletPrefab,transform.position,Quaternion.Euler(transform.eulerAngles+bulletEulerAngles));//ʵ�����ӵ�����Ҫʵ���������壬̹�˵�λ�ã���ת�Ƕ�
            attackTimeVal = 0;
        }
    }
    //̹�˵��ƶ�����
    private void tankMove()
    {
        //ÿһ֡��ʱ���ȳƣ���ÿһ����������
        float h = Input.GetAxisRaw("Horizontal");//�ĳ�GetAxisҲ����//h�ķ���ֵ��1/-1/0
        transform.Translate(Vector3.right * h * moveSpeed * Time.fixedDeltaTime, Space.World);//������������ֵ�ƶ�
        //ͨ��h��v��ֵ���ж�ǰ���������֪�����л���ʲôͼƬ
        if (h < 0)
        {
            //����ͼƬ�����ã���sprite[]����д�ɹ�����player->��������
            sr.sprite = tankSprite[3];
            bulletEulerAngles = new Vector3(0, 0, 90);

        }
        else if (h > 0)
        {
            sr.sprite = tankSprite[1];
            bulletEulerAngles = new Vector3(0, 0, -90);
        }
        //�����ƶ������ȼ�
        if (h != 0) { return; }

        float v = Input.GetAxisRaw("Vertical");
        transform.Translate(Vector3.up * v * moveSpeed * Time.fixedDeltaTime, Space.World);
        if (v < 0)
        {
            sr.sprite = tankSprite[2];
            bulletEulerAngles = new Vector3(0, 0, 180);
        }
        else if (v > 0)
        {
            sr.sprite = tankSprite[0];
            bulletEulerAngles = new Vector3(0, 0, 0);
        }
    }
    //̹�˵���������
    private void Die()
    {
        if (isDefended)
        {
            return;
        }
        //������ը��Ч
        Instantiate(explosionPrefab, transform.position, transform.rotation);
        //����
        Destroy(gameObject);//ע����������gameObject������GameObject
        PlayerManager.Instance.isDead=true;
        if(hasTeleportation==true)
        {
            Destroy(teleportMarker_test);
            hasTeleportation=false;
        }
    }
    private void SmallSkill()
    {
         if (Input.GetKeyDown(KeyCode.Q))
        {
            if (teleportMarker == null) // 如果当前没有传送标记
            {
                if (canTeleport) // 如果可以使用传送技能
                {
                    teleportMarker = Instantiate(teleportMarkerPrefab, transform.position, Quaternion.identity); // 在玩家位置生成传送标记
                    canTeleport = false; // 设置传送技能不可用
                }
            }
            else if (teleportMarker.transform.position != transform.position && !canTeleport) // 如果当前有传送标记，并且不在玩家位置上
            {
                transform.position = teleportMarker.transform.position; // 将玩家传送到传送标记位置
                Destroy(teleportMarker); // 销毁传送标记
                canTeleport = true; // 设置传送技能可用
            }
            else if (teleportMarker.transform.position == transform.position) // 如果当前有传送标记，并且在玩家位置上
            {
                Destroy(teleportMarker); // 销毁传送标记
                canTeleport = true; // 设置传送技能可用
            }
        }
    }
    private void SmallSkill_test()
    {
        if(Input.GetKeyDown(KeyCode.Q))
        {
            if(!hasTeleportation)
            {
                if(teleportMarker_test==null){
                teleportMarker_test=Instantiate(teleportMarkerPrefab,transform.position,Quaternion.identity);
                hasTeleportation=true;
            }
            
        }
            else if(hasTeleportation)
            {
                if(transform.position!=teleportMarker_test.transform.position){
                transform.position=teleportMarker_test.transform.position;
                }
                if(transform.position==teleportMarker_test.transform.position)
                {
                Destroy(teleportMarker_test);
                hasTeleportation=false;
                }
            }
        
        }
    }
}
