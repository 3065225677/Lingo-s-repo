using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour
{
    public AudioClip explosionAudio;
    // Start is called before the first frame update
    private void Awake()
    {
        AudioSource.PlayClipAtPoint(explosionAudio,transform.position);
    }
    void Start()
    {
        Destroy(gameObject, 0.167f);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
