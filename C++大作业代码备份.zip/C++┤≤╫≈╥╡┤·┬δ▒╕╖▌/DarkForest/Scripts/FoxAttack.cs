using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoxAttack : MonoBehaviour
{
    public int attackValue=15;
    public GameObject bloodEffect;
    private GameObject Cattle;
    private Transform tsOfCattle;
    void Start()
    {
        Cattle = GameObject.FindWithTag("CattleDuke");
        tsOfCattle=Cattle.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "CattleDuke":
                Instantiate(bloodEffect,tsOfCattle.position,Quaternion.identity);
                CattleHealth.healthCur -= attackValue;
                /*if (Input.GetKeyDown(KeyCode.Keypad0))
                {
                    CattleHealth.isAttacked = true;
                }
                Debug.Log("isAttacked="+CattleHealth.isAttacked);*/
                Debug.Log("fox��cattle����˺�");
                break;
            case "Chest":
                break;
            case "Enemy":
                collision.SendMessage("EnemyDie");
                Destroy(gameObject);
                break;
            case "Barrier":
                Destroy(gameObject);
                break;
            case "Wall":
                collision.SendMessage("Die");
                Destroy(gameObject);
                break;
            case "AirBarrier":
                Destroy(gameObject);
                break;
            default:
                break;
        }
    }
}
    
