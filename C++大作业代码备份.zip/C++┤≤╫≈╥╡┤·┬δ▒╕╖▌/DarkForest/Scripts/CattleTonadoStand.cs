using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CattleTonadoStand : MonoBehaviour
{
    public float durationTime=10.0f;
    public float tonadoStandHurtValue = 0.5f;
    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject,durationTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "FoxGeneral":
                FoxHealth.healthCur -= tonadoStandHurtValue;
                break;
        }
    }
}
