using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FoxHealth : MonoBehaviour
{
    public Text healthValueText;
    static public float healthCur =75;
    static public float healthMax =300;
    private Image healthBar;


    // Start is called before the first frame update
    void Awake()
    {
        healthBar=GetComponent<Image>();
        healthCur = healthMax;
    }

    // Update is called once per frame
    void Update()
    {
        healthBar.fillAmount = (float)healthCur / (float)healthMax;
        healthValueText.text= healthCur.ToString()+"/"+healthMax.ToString();
    }
}
