using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FoxGeneral : MonoBehaviour
{
    #region Setting
    //设置位移
    float move_h = 0;
    float move_v = 0;

    //引用
    private Animator _animator;
    private Rigidbody2D myRb; //fox自己的刚体组件
    private PolygonCollider2D attackUp_collider;//fox向上攻击时候的碰撞器
    private PolygonCollider2D attackDown_collider;
    private PolygonCollider2D attackRight_collider;
    private PolygonCollider2D attackLeft_collider;
    public GameObject attackUpHitBox;
    public GameObject attackDownHitBox;
    public GameObject attackRightHitBox;
    public GameObject attackLeftHitBox;
    public Text FoxSkillOneCD;
    public Text FoxSkillTwoCDTxt;
    //属性
    public float rollDistance = 5f; // 翻滚距离
    public float moveSpeed=3f;
    private float rollSpeed=0;
    private float rollMinSpeed=30;
    private float rollSpeedDropMultiplier=10;
    //CD
    public float attackTimeVal=0.5f;
    public float teleportTimeVal = 3.0f;
    public float rollTimeVal = 1.5f;


    public float rollCD=0;
    private float attackDir;
    private float attackCD=0;
    static public float teleportCD = 3;
   

    //技能&特效
    public GameObject teleportMarkerPrefab; // 传送标记预制体
    public GameObject teleportEffectPrefabs;//小技能（传送）特效预制体
    public GameObject teleportWeaponPrefab;
    private GameObject teleportWeapon;
    private GameObject teleportMarker;
    private GameObject teleportEffect;
    private Vector3 teleportWeaponEulerAngles;
    public int deltaAngle;
    private GameObject cattle;
    private GameObject FoxTeleportWeaponNotation;
   // private bool isTeleportWeaponSecondPhase=false;

    //状态值
    static public bool hasTeleportation = false;
    public float rollDiration = 4;
    private Vector3 moveDir;
    static public bool CanTeleportToAttack = false;
    private bool isDead = false;

    //分身
    public float FoxSkillTwoTimeVal = 5f;
    private float FoxSkillTwoCD = 5f;
    public GameObject cloneFoxPrefab;
    private GameObject cloneFox;
    public float cloneDuration = 30.0f; // 分身存在时间
    private float cloneTimer = 0.0f; // 分身存在时间计时器
    private bool isControllingClone = false; // 判断当前是否在控制分身
    private bool hasCloneFox = false;//判断当前是否存在分身
    public GameObject FoxSkillTwoEffectPrefab;
    private GameObject FoxSkillTwoEffect;

    public Text gameOver;
    #endregion
    void Awake()
    {
        _animator=GetComponent<Animator>();
        myRb = GetComponent<Rigidbody2D>();
        attackUp_collider = attackUpHitBox.GetComponent<PolygonCollider2D>();
        attackDown_collider = attackDownHitBox.GetComponent<PolygonCollider2D>();
        attackRight_collider = attackRightHitBox.GetComponent<PolygonCollider2D>(); 
        attackLeft_collider = attackLeftHitBox.GetComponent<PolygonCollider2D>();

        FoxTeleportWeaponNotation = GameObject.FindWithTag("FoxTeleportWeapon");
        cattle = GameObject.FindWithTag("CattleDuke");

    }
    void FixedUpdate()
    {
        if (isDead)
        {
            return;
        }
        Move();
        if (rollSpeed > rollMinSpeed)
        {
            rollSpeed -= rollSpeedDropMultiplier * Time.fixedDeltaTime;
        }
        
    }
    void Update()
    {
        if (FoxHealth.healthCur <= 0 && CattleHealth.healthCur <= 0)
        {
            hasTeleportation = false;
            CanTeleportToAttack = false;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
            gameOver.enabled = true;
            gameOver.text = "平局";
            Invoke("ReturnToMenu", 3);
        }
        else if (FoxHealth.healthCur <= 0)
        {
            hasTeleportation = false;
            CanTeleportToAttack = false;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
            gameOver.enabled = true;
            gameOver.text = "牛爵胜出";
            Invoke("ReturnToMenu", 3);
        }
        else if (CattleHealth.healthCur <= 0)
        {
            hasTeleportation = false;
            CanTeleportToAttack = false;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
            gameOver.enabled = true;
            gameOver.text = "狐将胜出";
            Invoke("ReturnToMenu", 3);
        }
        if (isDead)
        {
            return;
        }
        Die();
        move_h = 0;
        move_v = 0;
        
        if (attackCD>= attackTimeVal)
        {
            Attack();
        }
        else
        {
            attackCD+=Time.deltaTime;
        }

        if (rollCD>= rollTimeVal)
        {
            Roll();
        }
        else
        {
            rollCD+=Time.deltaTime;
        }

        Teleport();
        teleportCD += Time.deltaTime;

        if (teleportCD < teleportTimeVal)
        {
            FoxSkillOneCD.text = (teleportTimeVal - teleportCD).ToString();
        }
        else
        {
            FoxSkillOneCD.text = "准备完毕";
        }

        if ((!hasCloneFox)&&FoxSkillTwoCD >= FoxSkillTwoTimeVal)
        {
            FoxSkillTwo();
        }
        if((!hasCloneFox)&&(FoxSkillTwoCD < FoxSkillTwoTimeVal))
        {
            FoxSkillTwoCD += Time.deltaTime;
        }

        if (FoxSkillTwoCD < FoxSkillTwoTimeVal)
        {
            FoxSkillTwoCDTxt.text = (FoxSkillTwoTimeVal - FoxSkillTwoCD).ToString();
            if (hasCloneFox)
            {
             FoxSkillTwoCDTxt.text = "分身已存在！";
            }
        }
        else 
        {
            if (hasCloneFox)
            {
             FoxSkillTwoCDTxt.text = "已有分身，禁用";
            }
             FoxSkillTwoCDTxt.text = "准备完毕";
        }
        
        if (hasCloneFox && Input.GetKeyDown(KeyCode.F))
        {
            Destroy(cloneFox);
            Debug.Log("收回分身");
            hasCloneFox = false;
            isControllingClone = false;
        }
        if (hasCloneFox)
        {
            cloneTimer += Time.deltaTime;
            if (cloneTimer>cloneDuration)
            {
                Destroy(cloneFox);
                hasCloneFox = false;
                cloneTimer = 0;
                isControllingClone = false;
            }
        }
        //飞雷神二段
        if (Input.GetKeyDown(KeyCode.Z)&&CanTeleportToAttack && FoxTeleportWeapon.hasTeleportWeapon && hasTeleportation)
        {
            hasTeleportation = false;
            teleportMarker = Instantiate(teleportMarkerPrefab, transform.position, Quaternion.identity);
            teleportEffect = Instantiate(teleportEffectPrefabs, transform.position, Quaternion.identity);
            Destroy(teleportEffect, 0.417f);
            hasTeleportation = true;
            Debug.Log("按下了K，飞雷神二段");
            teleportCD = teleportTimeVal;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            if (!FoxTeleportWeapon.hasHitTheTarget)
            {
                transform.position = teleportWeapon.transform.position;
                Destroy(teleportWeapon);
                CanTeleportToAttack = false;
                
                
            }
            else
            {
                transform.position = cattle.transform.position;
                CanTeleportToAttack = false;
            }
            FoxTeleportWeaponNotation.GetComponent<SpriteRenderer>().enabled = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
        }
        
        //SwitchControll();
    }
    private void Move()
    {   
        
        move_h = Input.GetAxisRaw("Horizontal");
        move_v = Input.GetAxisRaw("Vertical");
        moveDir = new Vector3(move_h, move_v, 0).normalized;
        myRb.velocity = moveDir * moveSpeed;
        if (move_h>0)
        {
            _animator.SetFloat("Run_h",1);
            _animator.SetFloat("Run_v",0);
            _animator.SetFloat("idleDir",3);
            _animator.SetFloat("Attack",2);
            attackDir = 2;
            if (!FoxTeleportWeapon.hasTeleportWeapon)
            {
                teleportWeaponEulerAngles = new Vector3(0, 0, 0 + deltaAngle);
                FoxTeleportWeapon.index = 3;
            }
        }
        else if(move_h<0)
        {
           _animator.SetFloat("Run_h",-1);
            _animator.SetFloat("Run_v",0);
            _animator.SetFloat("idleDir",2);
            _animator.SetFloat("Attack",0);
            attackDir = 0;
            if (!FoxTeleportWeapon.hasTeleportWeapon)
            {
                teleportWeaponEulerAngles = new Vector3(0, 0, 180+deltaAngle);
                FoxTeleportWeapon.index = 2;
            }
        }
        else if(move_v>0)
        {
           _animator.SetFloat("Run_h",0);
            _animator.SetFloat("Run_v",1);
            _animator.SetFloat("idleDir",0);
            _animator.SetFloat("Attack",3);
            attackDir = 3;
            if (!FoxTeleportWeapon.hasTeleportWeapon)
            {
                teleportWeaponEulerAngles = new Vector3(0, 0, 90 + deltaAngle);
                FoxTeleportWeapon.index = 0;
            }

        }
        else if(move_v<0)
        {
           _animator.SetFloat("Run_h",0);
            _animator.SetFloat("Run_v",-1);
            _animator.SetFloat("idleDir",1);
             _animator.SetFloat("Attack",1);
            attackDir = 1;
            if (!FoxTeleportWeapon.hasTeleportWeapon)
            {
                teleportWeaponEulerAngles = new Vector3(0, 0, -90 + deltaAngle);
                FoxTeleportWeapon.index = 1;
            }
        }
        if(move_v!=0||move_h!=0)
        {
            if(!_animator.GetCurrentAnimatorStateInfo(0).IsName("Run"))
            {
                _animator.SetTrigger("isRun");
            }
           
            //Debug.Log("进入移动状态");
        }
        if(move_v==0&&move_h==0)
        {    
            _animator.SetTrigger("isStand");
    
        }
    }
    private void Roll()
    {

        if (Input.GetKeyDown(KeyCode.A))
        {
            rollDiration = 2;
            _animator.SetFloat("RollDir", 2);
        }
        else if (Input.GetKeyDown(KeyCode.D))
        {
            rollDiration = 3;
            _animator.SetFloat("RollDir", 3);
        }
        else if (Input.GetKeyDown(KeyCode.W))
        {
            rollDiration = 0;
            _animator.SetFloat("RollDir", 0);
        }
        else if (Input.GetKeyDown(KeyCode.S))
        {
            rollDiration = 1;
            _animator.SetFloat("RollDir", 1);
        }
        if (Input.GetKeyDown(KeyCode.L))
        {
            rollSpeed = 150;
            if (rollDiration == 4)
            {
                return;
            }
            else
            {
                rollCD = 0;
                _animator.SetTrigger("isRoll");
                Debug.Log("进入翻滚状态");
                if (rollDiration == 0)
                {
                    myRb.MovePosition(transform.position + moveDir * rollDistance);
                    myRb.velocity = moveDir * rollSpeed;
                  
                }
                if (rollDiration == 1)
                {
                    myRb.MovePosition(transform.position + moveDir * rollDistance);
                    myRb.velocity = moveDir * rollSpeed;
                    
                }
                if (rollDiration == 2)
                {
                    myRb.MovePosition(transform.position + moveDir * rollDistance);
                    myRb.velocity = moveDir * rollSpeed;
                    
                }
                if (rollDiration == 3)
                {
                    myRb.MovePosition(transform.position + moveDir * rollDistance);
                    myRb.velocity = moveDir * rollSpeed;
                   
                }
            }
        }
       
    }
    private void Attack()
    { 
       if(Input.GetKeyDown(KeyCode.J)&&attackDir==3)
        {
           
            attackCD =0;
            _animator.SetTrigger("isAttack");
            attackUp_collider.enabled = true;
            StartCoroutine(disableHitBox());
            
        }
        if (Input.GetKeyDown(KeyCode.J) && attackDir == 1)
        {
           
            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackDown_collider.enabled = true;
            StartCoroutine(disableHitBox());
            
        }
        if (Input.GetKeyDown(KeyCode.J) && attackDir == 2)
        {
            
            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackRight_collider.enabled = true;
            StartCoroutine(disableHitBox());
            
        }
        if (Input.GetKeyDown(KeyCode.J) && attackDir == 0)
        {
           
            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackLeft_collider.enabled = true;
            StartCoroutine(disableHitBox());
            
        }
        

    }
    IEnumerator disableHitBox()
    {
        yield return new WaitForSeconds(0.333f);
        attackUp_collider.enabled = false;
        attackDown_collider.enabled = false;
        attackRight_collider.enabled = false;
        attackLeft_collider.enabled = false;
    }
    private void Teleport()
    {   
        if (Input.GetKeyDown(KeyCode.Q))
        {
            Debug.Log("释放技能Q");
            if (!hasTeleportation)
            {
                if (teleportMarker == null)
                {
                    //感觉这里的判断有些多余
                    teleportMarker = Instantiate(teleportMarkerPrefab, transform.position, Quaternion.identity);
                    teleportEffect=Instantiate(teleportEffectPrefabs, transform.position, Quaternion.identity);
                    Destroy(teleportEffect,0.417f);
                    hasTeleportation = true;
                }

            }
            else if (hasTeleportation&&teleportMarker!=null)
            {
                if (transform.position == teleportMarker.transform.position)
                {
                    teleportCD = teleportTimeVal;
                }
                if (teleportCD >= teleportTimeVal)
                {
                    if (transform.position != teleportMarker.transform.position)
                    {
                        teleportEffect =Instantiate(teleportEffectPrefabs, transform.position, Quaternion.identity);
                        Destroy(teleportEffect, 0.417f);
                        transform.position = teleportMarker.transform.position;
                        teleportEffect = Instantiate(teleportEffectPrefabs, transform.position, Quaternion.identity);
                        teleportCD = 0;
                        Destroy(teleportEffect, 0.417f);
                    }
                    else if (transform.position == teleportMarker.transform.position)
                    {
                        Destroy(teleportMarker);
                        teleportEffect = Instantiate(teleportEffectPrefabs, transform.position, Quaternion.identity);
                        Destroy(teleportEffect, 0.417f);
                        hasTeleportation = false;
                    }
                }
                else
                {
                    teleportCD+= Time.deltaTime;
                }
            }

        }
        if (teleportCD>=teleportTimeVal)
        {
            if (Input.GetKeyDown(KeyCode.K) && !CanTeleportToAttack && !FoxTeleportWeapon.hasTeleportWeapon&& !hasTeleportation)
            {
                Debug.Log("按下了K，飞雷神一段");
                FoxTeleportWeapon.hasTeleportWeapon = true;
                hasTeleportation = true;
                teleportWeapon = Instantiate(teleportWeaponPrefab, transform.position, Quaternion.Euler(transform.eulerAngles + teleportWeaponEulerAngles));
                CanTeleportToAttack = true;
                
            }
        }
        else
        {
            teleportCD += Time.deltaTime;
        }
    }
    private void FoxSkillTwo()
    {
       
        if ((!hasCloneFox)&&Input.GetKeyDown(KeyCode.E))
        {
            cloneFox = Instantiate(cloneFoxPrefab, transform.position, Quaternion.identity);
            FoxSkillTwoEffect=Instantiate(FoxSkillTwoEffectPrefab,transform.position,Quaternion.identity);
            Destroy(FoxSkillTwoEffect, 1f);
            Debug.Log("分身成功");
            /*cloneFox.GetComponent<FoxCloneAI>().enabled = true;
            cloneFox.GetComponent<FoxClonePlayerControll>().enabled = false;*/
            gameObject.GetComponent<FoxGeneral>().enabled = true;
            gameObject.GetComponent<FoxAI>().enabled = false;
            hasCloneFox = true;
            Debug.Log("hasCloneFox=" + hasCloneFox);
            isControllingClone = false;
            FoxSkillTwoCD = 0;
        }
        

    }
    private void SwitchControll()
    {
        if (hasCloneFox = true&& Input.GetKeyDown(KeyCode.C)&&!isControllingClone)
        {
            /*cloneFox.GetComponent<FoxCloneAI>().enabled = false;
            cloneFox.GetComponent<FoxClonePlayerControll>().enabled = true;*/
            //gameObject.GetComponent<FoxGeneral>().enabled = false;
            //gameObject.GetComponent<FoxAI>().enabled = true;
            isControllingClone = true;
        }
        //下面这段应该写在FoxClonePlayerControll.cs里面
        if (hasCloneFox = true && Input.GetKeyDown(KeyCode.C) && isControllingClone)
        {
            /*cloneFox.GetComponent<FoxCloneAI>().enabled = true;
            cloneFox.GetComponent<FoxClonePlayerControll>().enabled = false;*/
            //gameObject.GetComponent<FoxGeneral>().enabled = true;
            //gameObject.GetComponent<FoxAI>().enabled = false;
            isControllingClone = false;
        }

    }
    IEnumerator WaitAWhile()
    {
        yield return new WaitForSeconds(10f);
    }
   private void Die()
    {
        if (FoxHealth.healthCur<=0)
        {
            _animator.SetTrigger("isDead");
            isDead = true;
            //StartCoroutine(WaitAWhile());
            //_animator.SetBool("isDie",false);
        }
    }
    private void ReturnToMenu()
    {
        SceneManager.LoadScene(0);
    }
}

