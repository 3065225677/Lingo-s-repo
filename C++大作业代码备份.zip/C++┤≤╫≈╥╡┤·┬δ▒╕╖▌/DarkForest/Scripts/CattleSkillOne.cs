using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CattleSkillOne : MonoBehaviour
{
     public float moveSpeed = 1.8f;
    private Vector3 iniPos;
    private Vector3 curPos;
    private Vector3[] moveDir = {Vector3.up,Vector3.down,Vector3.left,Vector3.right};
    public float moveDistance;
    static public int index;
    static public bool hasFireBall=false;
    public int FireBallHurtValue = 40;
    public GameObject fireOnGroundPrefab;
    public float fireOnGroundTimeVal=0.2f;
    public float fireOnGroundCD=0f;
    // Start is called before the first frame update
    void Awake()
    {
        iniPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(moveDir[index] * moveSpeed * Time.deltaTime, Space.World);
        if (fireOnGroundCD >= fireOnGroundTimeVal)
        {
            Instantiate(fireOnGroundPrefab, transform.position, Quaternion.identity);
            fireOnGroundCD = 0;
        }
        else
        {
            fireOnGroundCD += Time.deltaTime;
        }
        //transform.Translate(CattleDuke.moveDir * moveSpeed * Time.deltaTime, Space.World);
        curPos = transform.position;
            if (Mathf.Pow(iniPos.x - curPos.x, 2) + Mathf.Pow((iniPos.y - curPos.y), 2) > moveDistance * moveDistance)
            {
                Destroy(gameObject);
                hasFireBall= false;
            }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "FoxGeneral":
                FoxHealth.healthCur -= FireBallHurtValue;
                break;
        }
    }
}
