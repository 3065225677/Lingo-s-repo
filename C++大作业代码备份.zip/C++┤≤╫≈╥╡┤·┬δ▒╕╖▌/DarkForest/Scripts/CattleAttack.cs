using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CattleAttack : MonoBehaviour
{
    public int attackValue = 25;
    public GameObject bloodEffect;
    private GameObject Fox;
    private Transform tsOfFox;
    
    void Start()
    {
        Fox = GameObject.FindWithTag("FoxGeneral");
        tsOfFox = Fox.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "FoxGeneral":
                Instantiate(bloodEffect, tsOfFox.position, Quaternion.identity);
                FoxHealth.healthCur -= attackValue;
                Debug.Log("cattle��fox����˺�");
                break;
            case "Chest":
                break;
            case "Enemy":
                collision.SendMessage("EnemyDie");
                Destroy(gameObject);
                break;
            case "Barrier":
                Destroy(gameObject);
                break;
            case "Wall":
                collision.SendMessage("Die");
                Destroy(gameObject);
                break;
            case "AirBarrier":
                Destroy(gameObject);
                break;
            default:
                break;
        }
    }
}
