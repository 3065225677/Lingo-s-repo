using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CattleSkillTwo : MonoBehaviour
{
    public float moveSpeed = 1.8f;
    private Vector3 iniPos;
    private Vector3 curPos;
    private Vector3[] moveDir = {Vector3.up,Vector3.down,Vector3.left,Vector3.right};
    public float moveDistance;
    static public int index;
    static public bool hasTonado=false;
    public int tonadoHurtValue = 4;
    public GameObject tonadoStandPrefab;
    
    // Start is called before the first frame update
    void Awake()
    {
        iniPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(moveDir[index] * moveSpeed * Time.deltaTime, Space.World);
        //transform.Translate(CattleDuke.moveDir * moveSpeed * Time.deltaTime, Space.World);
        curPos = transform.position;
            if (Mathf.Pow(iniPos.x - curPos.x, 2) + Mathf.Pow((iniPos.y - curPos.y), 2) > moveDistance * moveDistance)
            {
                Destroy(gameObject);
                Instantiate(tonadoStandPrefab,transform.position,Quaternion.identity);
                hasTonado= false;
            }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "FoxGeneral":
                FoxHealth.healthCur -= tonadoHurtValue;
                break;
        }
    }
}
