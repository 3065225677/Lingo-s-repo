using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class FoxClone : MonoBehaviour
{
    public AIPath _aiPath;
    public AIDestinationSetter _destinationSetter;
    private PolygonCollider2D attackUp_collider;//fox���Ϲ���ʱ�����ײ��
    private PolygonCollider2D attackDown_collider;
    private PolygonCollider2D attackRight_collider;
    private PolygonCollider2D attackLeft_collider;
    public GameObject attackUpHitBox;
    public GameObject attackDownHitBox;
    public GameObject attackRightHitBox;
    public GameObject attackLeftHitBox;
    private GameObject cattleduke;
    private Animator _animator;
    private Rigidbody2D myRb; //fox�Լ��ĸ������
    private float attackDir;
    public float attackDistance=0.5f;
    private float attackCD = 0;
    public float attackTimeVal = 0.5f;

    void Awake()
    {
        _animator = GetComponent<Animator>();
        myRb = GetComponent<Rigidbody2D>();
        attackUp_collider = attackUpHitBox.GetComponent<PolygonCollider2D>();
        attackDown_collider = attackDownHitBox.GetComponent<PolygonCollider2D>();
        attackRight_collider = attackRightHitBox.GetComponent<PolygonCollider2D>();
        attackLeft_collider = attackLeftHitBox.GetComponent<PolygonCollider2D>();
        _destinationSetter=GetComponent<AIDestinationSetter>();
        _destinationSetter.target = GameObject.FindWithTag("CattleDuke").transform;
        cattleduke = GameObject.FindWithTag("CattleDuke");

    }


    void Update()
    {
        Move();
        Attack();
    }
    private void Move()
    {
        if (_aiPath.desiredVelocity.x >0.01f)
        {
            _animator.SetFloat("Run_h", 1);
            _animator.SetFloat("Run_v", 0);
            _animator.SetFloat("idleDir", 3);
            _animator.SetFloat("Attack", 2);
            attackDir = 2;
        }
        else if (_aiPath.desiredVelocity.x <-0.01f)
        {
            _animator.SetFloat("Run_h", -1);
            _animator.SetFloat("Run_v", 0);
            _animator.SetFloat("idleDir", 2);
            _animator.SetFloat("Attack", 0);
            attackDir = 0;
        }
        else if (_aiPath.desiredVelocity.y >0.01f)
        {
            _animator.SetFloat("Run_h", 0);
            _animator.SetFloat("Run_v", 1);
            _animator.SetFloat("idleDir", 0);
            _animator.SetFloat("Attack", 3);
            attackDir = 3;

        }
        else if (_aiPath.desiredVelocity.y < -0.01f)
        {
            _animator.SetFloat("Run_h", 0);
            _animator.SetFloat("Run_v", -1);
            _animator.SetFloat("idleDir", 1);
            _animator.SetFloat("Attack", 1);
            attackDir = 1;
        }
        if (_aiPath.desiredVelocity.y != 0 || _aiPath.desiredVelocity.x != 0)
        {
            if (!_animator.GetCurrentAnimatorStateInfo(0).IsName("Run"))
            {
                _animator.SetTrigger("isRun");
            }

            //Debug.Log("�����ƶ�״̬");
        }
        if (_aiPath.desiredVelocity.y == 0 || _aiPath.desiredVelocity.x == 0)
        {
            _animator.SetTrigger("isStand");

        }
    }
    private void Attack()
    {
        if (attackCD>=attackTimeVal)
        {
            if
            (Mathf.Pow(transform.position.x - cattleduke.transform.position.x, 2)
            + Mathf.Pow(transform.position.y - cattleduke.transform.position.y, 2)
            <= attackDistance * attackDistance)
            {
                if (attackDir == 3)
                {

                    attackCD = 0;
                    _animator.SetTrigger("isAttack");
                    attackUp_collider.enabled = true;
                    StartCoroutine(disableHitBox());
                    Debug.Log("�����ɹ�");
                }
                if (attackDir == 1)
                {

                    attackCD = 0;
                    _animator.SetTrigger("isAttack");
                    attackDown_collider.enabled = true;
                    StartCoroutine(disableHitBox());
                    Debug.Log("�����ɹ�");
                }
                if (attackDir == 2)
                {

                    attackCD = 0;
                    _animator.SetTrigger("isAttack");
                    attackRight_collider.enabled = true;
                    StartCoroutine(disableHitBox());
                    Debug.Log("�����ɹ�");
                }
                if (attackDir == 0)
                {

                    attackCD = 0;
                    _animator.SetTrigger("isAttack");
                    attackLeft_collider.enabled = true;
                    StartCoroutine(disableHitBox());
                    Debug.Log("�����ɹ�");
                }
            } 
        }
        else
        {
            attackCD += Time.deltaTime;
        }
    }
    IEnumerator disableHitBox()
    {
        yield return new WaitForSeconds(0.333f);
        attackUp_collider.enabled = false;
        attackDown_collider.enabled = false;
        attackRight_collider.enabled = false;
        attackLeft_collider.enabled = false;
    }
}
