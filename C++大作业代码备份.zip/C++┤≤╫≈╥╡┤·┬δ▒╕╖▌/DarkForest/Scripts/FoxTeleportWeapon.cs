using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoxTeleportWeapon : MonoBehaviour
{
    private Vector3[] moveDir = { Vector3.up, Vector3.down, Vector3.left, Vector3.right };
    private SpriteRenderer FoxTeleportWeaponNotationSpriteRenderer;
    public float moveSpeed = 1.8f;
    static public bool hasTeleportWeapon = false;
    static public int index;
    public int HurtValue = 40;
    public float moveDistance;
    private Vector3 iniPos;
    private Vector3 curPos;
    static public bool hasHitTheTarget = false;
    private float hurtValue = 10;
    // Start is called before the first frame update
    void Awake()
    {
        iniPos = transform.position;
        FoxTeleportWeaponNotationSpriteRenderer = GameObject.FindWithTag("FoxTeleportWeapon").GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(moveDir[index] * moveSpeed * Time.deltaTime, Space.World);
        //transform.Translate(CattleDuke.moveDir * moveSpeed * Time.deltaTime, Space.World);
        curPos = transform.position;
        if (!hasHitTheTarget)
        {
            if (Mathf.Pow(iniPos.x - curPos.x, 2) + Mathf.Pow((iniPos.y - curPos.y), 2) > moveDistance * moveDistance)
            {
                Destroy(gameObject);
                hasTeleportWeapon = false;
                FoxGeneral.hasTeleportation = false;
                FoxGeneral.CanTeleportToAttack = false;
                FoxGeneral.teleportCD = 0;
            }
        }
        
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "CattleDuke":
                CattleHealth.healthCur -= hurtValue;
                FoxTeleportWeaponNotationSpriteRenderer.enabled = true;
                Destroy(gameObject);
                hasHitTheTarget = true;
                hasTeleportWeapon= true;
                FoxGeneral.CanTeleportToAttack = true;
                FoxGeneral.hasTeleportation = true;
                break;
            case "CattleFireBall":
                Destroy(gameObject);
                Debug.Log("�������򱻴ݻ�");
                hasHitTheTarget = false;
                FoxGeneral.hasTeleportation = false;
                FoxGeneral.CanTeleportToAttack = false;
                FoxGeneral.teleportCD = 0;
                hasTeleportWeapon = false;
                break;
            case "CattleTonado":
                Destroy(gameObject);
                Debug.Log("��������������ݻ�");
                hasHitTheTarget = false;
                FoxGeneral.hasTeleportation = false;
                FoxGeneral.CanTeleportToAttack = false;
                FoxGeneral.teleportCD = 0;
                hasTeleportWeapon = false;
                break;
        }
    }
}
