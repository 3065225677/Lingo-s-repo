using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CattleFireOnGround : MonoBehaviour
{
    public float durationTime=3f;
    public float FireOnGroundHurtValue = 1;
    // Start is called before the first frame update
    void Start()
    {
        Destroy(gameObject,durationTime);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        switch (collision.tag)
        {
            case "FoxGeneral":
                FoxHealth.healthCur -= FireOnGroundHurtValue;
                break;
        }
    }
}
