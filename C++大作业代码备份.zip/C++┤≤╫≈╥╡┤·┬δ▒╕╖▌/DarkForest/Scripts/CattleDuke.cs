using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CattleDuke : MonoBehaviour
{
    #region setting
    //����λ��
    public float move_h;
    public float move_v;
    //
    static public Vector3 moveDir;
    //����
    private Animator _animator;
    public GameObject tonado;
    public GameObject fireBall;
    private Rigidbody2D myRb;
    public Text CattleSkillTwoCD;
    public Text CattleSkillOneCD;
    //����
    public float moveSpeed = 3f;
    //CD
    private float tonadoCD=5.0f;
    private float attackCD = 0f;

    public float tonadoTimeVal=5.0f;
    public float attackTimeVal = 0.3f;
    public float fireBallTimeVal=5.0f;
    public float fireBallCD= 5.0f;
    private Vector3 fireBallEulerAngles;

    public GameObject attackUpHitBox;
    public GameObject attackDownHitBox;
    public GameObject attackRightHitBox;
    public GameObject attackLeftHitBox;

    private PolygonCollider2D attackUp_collider;//cattle向上攻击时候的碰撞器
    private PolygonCollider2D attackDown_collider;
    private PolygonCollider2D attackRight_collider;
    private PolygonCollider2D attackLeft_collider;
    private float attackDir;

    public GameObject attackBackEffectPrefab;
    public float attackBackDuration = 0.3f;

    private bool isDead = false;
    [Header("Shift")]
    //Shift
    private float dashCD=3;
    public float dashTimeVal = 3.0f;
    public float dashDistance=8f;
    public GameObject dashEffect;
    private SpriteRenderer _sr;

    public Text gameOver;
    #endregion
    // Start is called before the first frame update
    void Awake()
    {
        _animator = GetComponent<Animator>();
        myRb = GetComponent<Rigidbody2D>();
        attackUp_collider = attackUpHitBox.GetComponent<PolygonCollider2D>();
        attackDown_collider = attackDownHitBox.GetComponent<PolygonCollider2D>();
        attackRight_collider = attackRightHitBox.GetComponent<PolygonCollider2D>();
        attackLeft_collider = attackLeftHitBox.GetComponent<PolygonCollider2D>();
        _sr=GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (isDead)
        {
            return;
        }
        Move();
    }
    void Update()
    {
        if (FoxHealth.healthCur <= 0 && CattleHealth.healthCur <= 0)
        {
            FoxGeneral.hasTeleportation = false;
            FoxGeneral.CanTeleportToAttack = false;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
            gameOver.enabled = true;
            gameOver.text = "平局";
            Invoke("ReturnToMenu", 3);
        }
        else if (FoxHealth.healthCur <= 0)
        {
            FoxGeneral.hasTeleportation = false;
            FoxGeneral.CanTeleportToAttack = false;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
            gameOver.enabled = true;
            gameOver.text = "牛爵胜出";
            Invoke("ReturnToMenu", 3);
        }
        else if (CattleHealth.healthCur <= 0)
        {
            FoxGeneral.hasTeleportation = false;
            FoxGeneral.CanTeleportToAttack = false;
            FoxTeleportWeapon.hasTeleportWeapon = false;
            FoxTeleportWeapon.hasHitTheTarget = false;
            gameOver.enabled = true;
            gameOver.text = "狐将胜出";
            Invoke("ReturnToMenu", 3);
        }
        if (isDead)
        {
            return;
        }
        Die();
        if (fireBallCD >= fireBallTimeVal)
        {
            FireBall();
        }
        else
        {
            fireBallCD += Time.deltaTime;
        }

          if (tonadoCD >= tonadoTimeVal)
        {
            Tonado();
        }
        else
        {
            tonadoCD += Time.deltaTime;
        }

        if (attackCD >= attackTimeVal)
        {
            Attack();
        }
        else
        {
            attackCD += Time.deltaTime;
        }
        //冷却UI
        if (tonadoCD < tonadoTimeVal)
        {
            CattleSkillTwoCD.text = (tonadoTimeVal - tonadoCD).ToString();
        }
        else
        {
            CattleSkillTwoCD.text = "准备完毕";
        }

        if (fireBallCD < fireBallTimeVal)
        {
            CattleSkillOneCD.text = (fireBallTimeVal - fireBallCD).ToString();
        }
        else
        {
            CattleSkillOneCD.text = "准备完毕";
        }
        AttackBack();
        Dash();
    }
    private void Move()
    {

        move_h = Input.GetAxisRaw("CattleH");
        move_v = Input.GetAxisRaw("CattleV");
        moveDir = new Vector3(move_h, move_v, 0).normalized;
        myRb.velocity = moveDir * moveSpeed;
        if (move_h > 0)
        {
            _animator.SetFloat("Run_h", 1);
            _animator.SetFloat("Run_v", 0);
            _animator.SetFloat("idleDir", 3);
            _animator.SetFloat("Attack", 2);
            attackDir = 2;
            if (!CattleSkillTwo.hasTonado)
            {
                CattleSkillTwo.index = 3;
            }
           if (!CattleSkillOne.hasFireBall)
            {
                fireBallEulerAngles = new Vector3(0, 0, 0);
                CattleSkillOne.index = 3;
            }
           

        }
        else if (move_h < 0)
        {
            _animator.SetFloat("Run_h", -1);
            _animator.SetFloat("Run_v", 0);
            _animator.SetFloat("idleDir", 2);
            _animator.SetFloat("Attack", 0);
            attackDir = 0;
            if (!CattleSkillTwo.hasTonado)
            {
                CattleSkillTwo.index = 2;
            }
            if (!CattleSkillOne.hasFireBall)
            {
                fireBallEulerAngles = new Vector3(0, 0, 180);
                CattleSkillOne.index = 2;
            }
        }
       
     
        
        if (move_v > 0)
        {
            _animator.SetFloat("Run_h", 0);
            _animator.SetFloat("Run_v", 1);
            _animator.SetFloat("idleDir", 0);
            _animator.SetFloat("Attack", 3);
            attackDir = 3;
            if (!CattleSkillTwo.hasTonado)
            {
                CattleSkillTwo.index = 0;
            }
            if (!CattleSkillOne.hasFireBall)
            {
                fireBallEulerAngles = new Vector3(0, 0, 90);

                CattleSkillOne.index = 0;
            }
            
        }
        else if (move_v < 0)
        {
            _animator.SetFloat("Run_h", 0);
            _animator.SetFloat("Run_v", -1);
            _animator.SetFloat("idleDir", 1);
            _animator.SetFloat("Attack", 1);
            attackDir = 1;
            if (!CattleSkillTwo.hasTonado)
            {
                CattleSkillTwo.index = 1;
            }
           if (!CattleSkillOne.hasFireBall)
            {
                fireBallEulerAngles = new Vector3(0, 0, -90);
                CattleSkillOne.index = 1;
            }
            
        }
        if (move_v != 0 || move_h != 0)
        {
            if (!_animator.GetCurrentAnimatorStateInfo(0).IsName("Run"))
            {
                _animator.SetTrigger("isRun");
            }

            //Debug.Log("�����ƶ�״̬");
        }
        if (move_v == 0 && move_h == 0)
        {
            _animator.SetTrigger("isStand");

        }
    }
    private void Attack()
    {
        if (Input.GetKeyDown(KeyCode.Keypad1) && attackDir == 3)
        {

            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackUp_collider.enabled = true;
            StartCoroutine(disableHitBox());
            Debug.Log("攻击成功");
        }
        if (Input.GetKeyDown(KeyCode.Keypad1) && attackDir == 1)
        {

            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackDown_collider.enabled = true;
            StartCoroutine(disableHitBox());
            Debug.Log("攻击成功");
        }
        if (Input.GetKeyDown(KeyCode.Keypad1) && attackDir == 2)
        {

            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackRight_collider.enabled = true;
            StartCoroutine(disableHitBox());
            Debug.Log("攻击成功");
        }
        if (Input.GetKeyDown(KeyCode.Keypad1) && attackDir == 0)
        {

            attackCD = 0;
            _animator.SetTrigger("isAttack");
            attackLeft_collider.enabled = true;
            StartCoroutine(disableHitBox());
            Debug.Log("攻击成功");
        }
    }
    IEnumerator disableHitBox()
    {
        yield return new WaitForSeconds(0.333f);
        attackUp_collider.enabled = false;
        attackDown_collider.enabled = false;
        attackRight_collider.enabled = false;
        attackLeft_collider.enabled = false;
    }
    private void Tonado()
    {
        if (Input.GetKeyDown(KeyCode.Keypad3))
        {
            CattleSkillTwo.hasTonado = true;
            Instantiate(tonado, transform.position, Quaternion.identity);
            tonadoCD = 0;
        }
    }
    private void FireBall()
    {
        if (Input.GetKeyDown(KeyCode.Keypad2))
        {
            CattleSkillOne.hasFireBall = true;
            Instantiate(fireBall, transform.position, Quaternion.Euler(transform.eulerAngles + fireBallEulerAngles));
            fireBallCD = 0;
        }
    }
    private void AttackBack()
    {
        /*if (CattleHealth.isAttacked)
        {
            CattleHealth.isAttacked = false;
            Instantiate(attackBackEffectPrefab,transform.position,Quaternion.identity);

        }*/
    }
    private void Die()
    {
        if (CattleHealth.healthCur <= 0)
        {
            _animator.SetTrigger("isDead");
            isDead = true;
            //StartCoroutine(WaitAWhile());
            //_animator.SetBool("isDie",false);
        }
    }
    private void Dash()
    {
        if (dashCD>=dashTimeVal)
        {
            Vector3 dashDir = new Vector3(move_h,move_v,0).normalized;
            if (Input.GetKeyDown(KeyCode.Keypad0))
            {
                _animator.SetTrigger("isDash");
                dashCD = 0;
                //myRb.AddForce(dashDir*dashForceMagnitude,ForceMode2D.Impulse);
                //myRb.velocity = dashDir * dashForceMagnitude ;
                Debug.Log("冲击成功");
                _sr.enabled = false;
                Instantiate(dashEffect, transform.position,Quaternion.identity);
                transform.position += dashDir * dashDistance;
                
                //transform.Translate(dashDir * dashDistance * Time.deltaTime*500, Space.World);
                Instantiate(dashEffect, transform.position, Quaternion.identity);
                Invoke("Wait",0.1f);
                //Debug.Log(myRb.velocity);

            }
            
        }
        else
        {
            dashCD += Time.deltaTime;
        }
        
    }
   private void Wait()
    {
        _sr.enabled = true;
    }
    private void ReturnToMenu()
    {
        SceneManager.LoadScene(0);
    }
}

